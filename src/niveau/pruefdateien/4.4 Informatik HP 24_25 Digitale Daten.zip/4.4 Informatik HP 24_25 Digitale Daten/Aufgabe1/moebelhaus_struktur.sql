-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema moebelhaus
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema moebelhaus
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `moebelhaus` DEFAULT CHARACTER SET utf8 ;
USE `moebelhaus` ;

-- -----------------------------------------------------
-- Table `moebelhaus`.`kategorien`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `moebelhaus`.`kategorien` (
  `kategorieNr` INT NOT NULL,
  `kategoriename` VARCHAR(45) NULL,
  PRIMARY KEY (`kategorieNr`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `moebelhaus`.`moebelstuecke`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `moebelhaus`.`moebelstuecke` (
  `moebelstueckNr` INT NOT NULL,
  `bezeichnung` VARCHAR(45) NULL,
  `preis` DOUBLE NULL,
  `kategorieNr` INT NOT NULL,
  PRIMARY KEY (`moebelstueckNr`),
  INDEX `fk_moebelstuecke_kategorien1_idx` (`kategorieNr` ASC),
  CONSTRAINT `fk_moebelstuecke_kategorien1`
    FOREIGN KEY (`kategorieNr`)
    REFERENCES `moebelhaus`.`kategorien` (`kategorieNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `moebelhaus`.`einzelteile`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `moebelhaus`.`einzelteile` (
  `einzelteilNr` INT NOT NULL,
  `bezeichnung` VARCHAR(45) NULL,
  `gewicht_in_gramm` DOUBLE NULL,
  PRIMARY KEY (`einzelteilNr`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `moebelhaus`.`stuecklisten`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `moebelhaus`.`stuecklisten` (
  `nr` INT NOT NULL,
  `moebelstueckNr` INT NOT NULL,
  `einzelteilNr` INT NOT NULL,
  `anzahl` INT NULL,
  INDEX `fk_moebelstuecke_has_einzelteile_einzelteile1_idx` (`einzelteilNr` ASC),
  INDEX `fk_moebelstuecke_has_einzelteile_moebelstuecke_idx` (`moebelstueckNr` ASC),
  PRIMARY KEY (`nr`),
  CONSTRAINT `fk_moebelstuecke_has_einzelteile_moebelstuecke`
    FOREIGN KEY (`moebelstueckNr`)
    REFERENCES `moebelhaus`.`moebelstuecke` (`moebelstueckNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_moebelstuecke_has_einzelteile_einzelteile1`
    FOREIGN KEY (`einzelteilNr`)
    REFERENCES `moebelhaus`.`einzelteile` (`einzelteilNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
