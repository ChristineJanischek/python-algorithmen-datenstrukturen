-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema frisoer
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `frisoer` DEFAULT CHARACTER SET utf8 ;
USE `frisoer` ;

-- -----------------------------------------------------
-- Table `frisoer`.`kunden`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `frisoer`.`kunden` (
  `kundenNr` INT NOT NULL,
  `vorname` VARCHAR(45) NULL,
  `nachname` VARCHAR(45) NULL,
  `telefon` VARCHAR(45) NULL,
  PRIMARY KEY (`kundenNr`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `frisoer`.`dienstleistungen`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `frisoer`.`dienstleistungen` (
  `leistungsNr` INT NOT NULL,
  `bezeichnung` VARCHAR(45) NULL,
  `preis` DOUBLE NULL,
  `dauer` INT NULL,
  PRIMARY KEY (`leistungsNr`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `frisoer`.`termine`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `frisoer`.`termine` (
  `terminNr` INT NOT NULL,
  `datum` DATE NULL,
  `uhrzeit` VARCHAR(45) NULL,
  `kundenNr` INT NOT NULL,
  PRIMARY KEY (`terminNr`),
  INDEX `fk_termine_kunden_idx` (`kundenNr` ASC),
  CONSTRAINT `fk_termine_kunden`
    FOREIGN KEY (`kundenNr`)
    REFERENCES `frisoer`.`kunden` (`kundenNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `frisoer`.`termineDienstleistungen`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `frisoer`.`termineDienstleistungen` (
  `terminDienstleistungNr` INT NOT NULL,
  `terminNr` INT NOT NULL,
  `leistungsNr` INT NOT NULL,
  INDEX `fk_termine_has_dienstleistungen_dienstleistungen1_idx` (`leistungsNr` ASC),
  INDEX `fk_termine_has_dienstleistungen_termine1_idx` (`terminNr` ASC),
  PRIMARY KEY (`terminDienstleistungNr`),
  CONSTRAINT `fk_termine_has_dienstleistungen_termine1`
    FOREIGN KEY (`terminNr`)
    REFERENCES `frisoer`.`termine` (`terminNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_termine_has_dienstleistungen_dienstleistungen1`
    FOREIGN KEY (`leistungsNr`)
    REFERENCES `frisoer`.`dienstleistungen` (`leistungsNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
