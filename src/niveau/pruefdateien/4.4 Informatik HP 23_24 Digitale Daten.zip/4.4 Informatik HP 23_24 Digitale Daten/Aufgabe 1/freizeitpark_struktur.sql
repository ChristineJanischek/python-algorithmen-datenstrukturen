SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

DROP SCHEMA IF EXISTS `freizeitpark` ;
CREATE SCHEMA IF NOT EXISTS `freizeitpark` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `freizeitpark` ;

-- -----------------------------------------------------
-- Table `freizeitpark`.`kategorien`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `freizeitpark`.`kategorien` (
  `kategorieNr` INT NOT NULL,
  `bezeichnung` VARCHAR(45) NULL,
  PRIMARY KEY (`kategorieNr`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `freizeitpark`.`artikel`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `freizeitpark`.`artikel` (
  `artikelNr` INT NOT NULL,
  `bezeichnung` VARCHAR(45) NULL,
  `preis` DOUBLE NULL,
  `kategorieNr` INT NOT NULL,
  PRIMARY KEY (`artikelNr`),
  INDEX `fk_artikel_kategorien1_idx` (`kategorieNr` ASC),
  CONSTRAINT `fk_artikel_kategorien1`
    FOREIGN KEY (`kategorieNr`)
    REFERENCES `freizeitpark`.`kategorien` (`kategorieNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `freizeitpark`.`mitarbeiter`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `freizeitpark`.`mitarbeiter` (
  `mitarbeiterNr` INT NOT NULL,
  `vorname` VARCHAR(45) NULL,
  `nachname` VARCHAR(45) NULL,
  PRIMARY KEY (`mitarbeiterNr`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `freizeitpark`.`verkaeufe`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `freizeitpark`.`verkaeufe` (
  `verkaufNr` INT NOT NULL,
  `datum` DATE NULL,
  `mitarbeiterNr` INT NOT NULL,
  PRIMARY KEY (`verkaufNr`),
  INDEX `fk_verkaeufe_mitarbeiter1_idx` (`mitarbeiterNr` ASC),
  CONSTRAINT `fk_verkaeufe_mitarbeiter1`
    FOREIGN KEY (`mitarbeiterNr`)
    REFERENCES `freizeitpark`.`mitarbeiter` (`mitarbeiterNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `freizeitpark`.`verkaufpositionen`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `freizeitpark`.`verkaufspositionen` (
  `positionNr` INT NOT NULL,
  `anzahl` INT NULL,
  `artikelNr` INT NOT NULL,
  `verkaufNr` INT NOT NULL,
  PRIMARY KEY (`positionNr`),
  INDEX `fk_verkaufspositionen_artikel1_idx` (`artikelNr` ASC),
  INDEX `fk_verkaufspositionen_verkaeufe1_idx` (`verkaufNr` ASC),
  CONSTRAINT `fk_verkaufspositionen_artikel1`
    FOREIGN KEY (`artikelNr`)
    REFERENCES `freizeitpark`.`artikel` (`artikelNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_verkaufspositionen_verkaeufe1`
    FOREIGN KEY (`verkaufNr`)
    REFERENCES `freizeitpark`.`verkaeufe` (`verkaufNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
