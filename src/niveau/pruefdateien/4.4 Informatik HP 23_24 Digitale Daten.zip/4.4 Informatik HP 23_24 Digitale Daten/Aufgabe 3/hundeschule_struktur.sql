SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

DROP SCHEMA IF EXISTS `hundeschule` ;
CREATE SCHEMA IF NOT EXISTS `hundeschule` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `hundeschule` ;

-- -----------------------------------------------------
-- Table `hundeschule`.`besitzer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hundeschule`.`besitzer` (
  `besitzerNr` INT NOT NULL,
  `vorname` VARCHAR(45) NULL,
  `nachname` VARCHAR(45) NULL,
  `telefonnummer` VARCHAR(45) NULL,
  PRIMARY KEY (`besitzerNr`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hundeschule`.`hunde`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hundeschule`.`hunde` (
  `hundNr` INT NOT NULL,
  `hundename` VARCHAR(45) NULL,
  `geburtsdatum` DATE NULL,
  `besitzerNr` INT NOT NULL,
  PRIMARY KEY (`hundNr`),
  INDEX `fk_hunde_besitzer_idx` (`besitzerNr` ASC),
  CONSTRAINT `fk_hunde_besitzer`
    FOREIGN KEY (`besitzerNr`)
    REFERENCES `hundeschule`.`besitzer` (`besitzerNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hundeschule`.`trainer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hundeschule`.`trainer` (
  `trainerNr` INT NOT NULL,
  `vorname` VARCHAR(45) NULL,
  `nachname` VARCHAR(45) NULL,
  PRIMARY KEY (`trainerNr`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hundeschule`.`kurse`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hundeschule`.`kurse` (
  `kursNr` INT NOT NULL,
  `bezeichnung` VARCHAR(45) NULL,
  `preis` DOUBLE NULL,
  `trainerNr` INT NOT NULL,
  PRIMARY KEY (`kursNr`),
  INDEX `fk_kurse_trainer1_idx` (`trainerNr` ASC),
  CONSTRAINT `fk_kurse_trainer1`
    FOREIGN KEY (`trainerNr`)
    REFERENCES `hundeschule`.`trainer` (`trainerNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hundeschule`.`belegungen`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hundeschule`.`belegungen` (
  `belegungNr` INT NOT NULL,
  `hundNr` INT NOT NULL,
  `kursNr` INT NOT NULL,
  PRIMARY KEY (`belegungNr`),
  INDEX `fk_hunde_has_kurse_kurse1_idx` (`kursNr` ASC),
  INDEX `fk_hunde_has_kurse_hunde1_idx` (`hundNr` ASC),
  CONSTRAINT `fk_hunde_has_kurse_hunde1`
    FOREIGN KEY (`hundNr`)
    REFERENCES `hundeschule`.`hunde` (`hundNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_hunde_has_kurse_kurse1`
    FOREIGN KEY (`kursNr`)
    REFERENCES `hundeschule`.`kurse` (`kursNr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
